/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

const course1 = [
  { day: 1, title: "Foundations", items: ["Introduction of Numerology", "Understanding the Cheiro System"] },
  { day: 2, title: "Core Numbers I", items: ["Characteristics of Numbers (1–4)"] },
  { day: 3, title: "Core Numbers II", items: ["Characteristics of Numbers (5–9)"] },
  { day: 4, title: "Number Frequencies", items: ["Presence of Numbers more than 1 in date of birth", "Practical examples"] },
  { day: 5, title: "Grid Systems", items: ["Lo Shu Grid", "Basic calculations and chart making"] },
  { day: 6, title: "Life Path", items: ["Destiny Number", "How to calculate and interpret"] },
  { day: 7, title: "The Void", items: ["Impact of missing numbers", "Practical analysis"] },
  { day: 8, title: "Directional Energy", items: ["Arrows of Numerology", "Strengths and weaknesses"] },
  { day: 9, title: "Time Cycles", items: ["Personal Year", "How to predict yearly cycles"] },
  { day: 10, title: "Relationships", items: ["Compatibility in Numerology", "Business partner and marriage compatibility"] },
  { day: 11, title: "Foresight & Healing", items: ["Prediction methods", "Remedies (General & Element Based)"] },
  { day: 12, title: "Higher Vibrations", items: ["Master Numbers (11, 22, 33)", "Number combinations"] },
  { day: 13, title: "Auspicious Elements", items: ["Lucky Colors & Lucky Numbers", "Month Number"] },
  { day: 14, title: "Karmic Debt", items: ["Karmic Numbers (13, 14, 16, 19)", "Education analysis through numerology"] },
  { day: 15, title: "Integration", items: ["Tips of Numerology", "Practical examples and doubt solving"] },
];

const course2 = [
  { day: 1, title: "Core Fundamentals", items: ["Introduction of Numerology", "Understanding the Cheiro System", "Characteristics of Numbers (1–9)", "Presence of Numbers more than 1 in date of birth"] },
  { day: 2, title: "Grids & Destiny", items: ["Lo Shu Grid with basic calculation", "Destiny Number", "Impact of missing numbers", "Arrows of Numerology"] },
  { day: 3, title: "Cycles & Compatibility", items: ["Personal Year", "Compatibility (Business Partner & Marriage)", "Prediction and Remedy (General & Element Based)", "Master Numbers (11, 22, 33)"] },
  { day: 4, title: "Advanced Application", items: ["Number Combinations", "Lucky Colors & Lucky Numbers", "Month Number", "Karmic Numbers (13, 14, 16, 19)", "Education", "Tips of Numerology", "Practical examples and doubt solving session"] },
];

const Logo = ({ dark = true }) => (
  <div className="flex items-center gap-4">
    <svg width="56" height="56" viewBox="0 0 64 64" fill="currentColor" className={dark ? "text-paper" : "text-ink"}>
      {/* Robes */}
      <path d="M32 36 C18 36, 10 48, 8 60 L56 60 C54 48, 46 36, 32 36 Z" />
      {/* Head */}
      <path d="M32 8 C25 8, 20 14, 20 24 C20 32, 25 38, 32 38 C39 38, 44 32, 44 24 C44 14, 39 8, 32 8 Z" />
      {/* Sunglasses (cutout using opposite color) */}
      <path d="M18 22 L46 22 L44 28 L34 28 L32 25 L30 28 L20 28 Z" fill={dark ? "var(--ink)" : "var(--paper)"} />
      {/* Tilak */}
      <path d="M31 12 L33 12 L32.5 18 L31.5 18 Z" fill={dark ? "var(--ink)" : "var(--paper)"} />
    </svg>
    <div className="flex flex-col">
      <span className={`font-syne font-extrabold text-2xl md:text-3xl tracking-widest leading-none ${dark ? 'text-paper' : 'text-ink'}`}>URBAN PANDIT</span>
      <span className={`font-mono text-[0.6rem] md:text-[0.65rem] tracking-[0.18em] mt-1.5 font-semibold ${dark ? 'text-gold' : 'text-accent'}`}>MODERN MIND ANCIENT WISDOM</span>
    </div>
  </div>
);

export default function App() {
  return (
    <div>
      {/* COVER */}
      <div className="cover">
        <div className="cover-logo" style={{ textTransform: 'none', letterSpacing: 'normal' }}>
          <Logo dark={true} />
        </div>
        <div className="cover-hero">
          <div className="cover-eyebrow">// Modern Mind · Ancient Wisdom</div>
          <h1 className="cover-title" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>Discover the Power of<br/><span className="text-gold">Numbers</span> in Your Life</h1>
          <p className="cover-sub">
            A practical, time-tested guide to self-awareness, better decisions, and meaningful predictions.
          </p>
          <a 
            href="https://forms.gle/Gh2Mbdgrh7r27YPfA" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="inline-block bg-accent text-white font-syne font-bold uppercase tracking-widest text-sm px-8 py-4 mt-8 hover:bg-accent2 transition-colors duration-300"
          >
            Enroll Now
          </a>
        </div>
        <div className="cover-meta">
          <div><strong>Format</strong>Live Online / Hybrid</div>
          <div><strong>Curriculum</strong>Cheiro & Lo Shu</div>
          <div><strong>Audience</strong>Seekers & Professionals</div>
          <div><strong>Start Date</strong>April 1st, 2026</div>
        </div>
      </div>

      {/* TOC */}
      <div className="toc">
        <div className="toc-title">// Table of Contents</div>
        <div className="toc-grid">
          <a href="#about" className="toc-item"><span className="toc-num">01</span><span className="toc-label">Mapping the Unpredictable</span></a>
          <a href="#advantages" className="toc-item"><span className="toc-num">02</span><span className="toc-label">The Urban Pandit Advantage</span></a>
          <a href="#course1" className="toc-item"><span className="toc-num">03</span><span className="toc-label">15-Day Comprehensive Journey</span></a>
          <a href="#course2" className="toc-item"><span className="toc-num">04</span><span className="toc-label">4-Day Corporate Intensive</span></a>
        </div>
      </div>

      {/* 01. MAPPING THE UNPREDICTABLE */}
      <div className="page" id="about">
        <div className="section-label">// 01 — Philosophy</div>
        <h1 className="section-title">Mapping the Unpredictable</h1>
        
        <p className="lead">
          Numerology is not guesswork. It is a highly practical, time-tested system to decode the numeric vibrations that influence your personality, events, and ultimate life direction.
        </p>

        <h2>The Cheiro System</h2>
        <p>
          Bridging Ancient Wisdom & the Modern Mind, the Cheiro system uses your Date of Birth and Name to create a Numerological Blueprint. This blueprint empowers you with Career & Business Strategy, Relationship Compatibility, and Targeted Remedies.
        </p>

        <h2>Who Uses the Power of Numbers?</h2>
        <div className="card-grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))' }}>
          <div className="card">
            <div className="card-title">The Executive & Entrepreneur</div>
            <div className="card-body">Use numbers to choose launch dates, evaluate business partnerships, and define brand identity.</div>
          </div>
          <div className="card">
            <div className="card-title">The HR Manager & Team Builder</div>
            <div className="card-body">Read a basic chart in minutes to understand candidates instantly, identify team roles, and manage interpersonal dynamics.</div>
          </div>
          <div className="card">
            <div className="card-title">The Healer & Coach</div>
            <div className="card-body">Integrate a powerful diagnostic tool to read clients' deeper personality patterns and offer rapid, actionable guidance.</div>
          </div>
          <div className="card">
            <div className="card-title">The Seeker</div>
            <div className="card-body">Uncover your true destiny number, understand karmic lessons, and harmonize your personal relationships.</div>
          </div>
        </div>
      </div>

      {/* 02. THE URBAN PANDIT ADVANTAGE */}
      <div className="section-divider" id="advantages">
        <div className="num">02</div>
        <h2>The Urban Pandit Advantage</h2>
        <p>Transforming Numbers into Strategy.</p>
      </div>

      <div className="page">
        <div className="card-grid">
          <div className="card">
            <div className="card-icon">🏛️</div>
            <div className="card-title">Ancient Depth</div>
            <div className="card-body">Structured, step-by-step mastery of the traditional Cheiro system.</div>
          </div>
          <div className="card blue">
            <div className="card-icon">🧠</div>
            <div className="card-title">Modern Mindset</div>
            <div className="card-body">A practical focus on real-world application, stripping away superstition to provide actionable data.</div>
          </div>
          <div className="card gold">
            <div className="card-icon">⚡</div>
            <div className="card-title">Live Integration</div>
            <div className="card-body">Practice-oriented sessions utilizing real-life examples and active doubt-solving.</div>
          </div>
        </div>
      </div>

      {/* 03. 15-DAY COMPREHENSIVE JOURNEY */}
      <div className="section-divider" id="course1">
        <div className="num">03</div>
        <h2>The 15-Day Comprehensive Journey</h2>
        <p>A complete, step-by-step immersion into the Cheiro system. From absolute beginner to confident practitioner, capable of reading charts, predicting cycles, and prescribing remedies.</p>
      </div>

      <div className="page">
        <div className="roadmap">
          {course1.map((dayData, index) => (
            <div className="phase" key={`c1-day-${dayData.day}`}>
              <div className={`phase-label ${index % 3 === 0 ? 'p1' : index % 3 === 1 ? 'p2' : 'p3'}`}>
                Day {dayData.day}
              </div>
              <div className="phase-content">
                <div className="phase-title">{dayData.title}</div>
                <div className="phase-items">
                  {dayData.items.join(' • ')}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 04. 4-DAY CORPORATE INTENSIVE */}
      <div className="section-divider" id="course2">
        <div className="num">04</div>
        <h2>The 4-Day Corporate Intensive</h2>
        <p>Designed specifically for the modern professional. A highly concentrated, weekend-only framework to rapidly acquire practical numerology tools for hiring, networking, and strategic timing.</p>
      </div>

      <div className="page">
        <div className="roadmap">
          {course2.map((dayData, index) => (
            <div className="phase" key={`c2-day-${dayData.day}`}>
              <div className={`phase-label ${index % 3 === 0 ? 'p1' : index % 3 === 1 ? 'p2' : 'p3'}`}>
                Day {dayData.day}
              </div>
              <div className="phase-content">
                <div className="phase-title">{dayData.title}</div>
                <div className="phase-items">
                  {dayData.items.join(' • ')}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="callout" style={{ marginTop: '4rem' }}>
          <strong>Reserve Your Seat</strong>
          <p>Batch sizes are strictly limited to ensure personal attention and quality mentorship. Both the 15-Day Comprehensive Journey and the 4-Day Corporate Intensive begin on April 1st.</p>
          <a 
            href="https://forms.gle/Gh2Mbdgrh7r27YPfA" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="inline-block bg-ink text-paper font-syne font-bold uppercase tracking-widest text-sm px-8 py-4 mt-6 hover:bg-accent transition-colors duration-300"
          >
            Fill Enrollment Form
          </a>
        </div>
      </div>

      {/* FOOTER */}
      <div style={{ background: 'var(--paper)', color: 'var(--ink)', padding: '4rem 3rem', borderTop: '1px solid var(--rule)' }}>
        <div className="flex flex-col md:flex-row justify-between items-center gap-8 max-w-[960px] mx-auto">
          <Logo dark={false} />
          <div className="font-mono text-xs text-muted text-center md:text-right leading-relaxed">
            <p>Batch sizes are strictly limited to ensure personal attention and quality mentorship.</p>
            <p className="mt-2">© 2026 Urban Pandit. All Rights Reserved.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
